# Semester_Project
## Name: Ofori Benjamin Amponsah
## Program: Information Technology (I.T) (B)
## Index Number: UEB3211222

Project Description
##  USSD System
The USSD System Mini Console Application is a C++ project designed to simulate
a simplified USSD (Unstructured Supplementary Service Data) system. USSD
codes are short codes used by mobile network operators to provide quick access
to various services and information. This project aims to create a mini console
application that incorporates a selection of 10 USSD codes, each associated with
specific operations, allowing users to interact with the system in a user-friendly
manner. The recommended features for the USSD System Mini Console
Application include a main menu with 10 USSD codes, user-friendly input and
error handling, functionalities such as balance inquiry, data plan activation,
account recharge, transaction history, profile viewing, customer support access,
language selection, and a clean exit option.
